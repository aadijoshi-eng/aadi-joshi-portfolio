local table_index = 0
local widths = {
  {0.30,0.15,0.10,0.12,0.25,0.08},
  {0.83,0.17},
  {0.14,0.18,0.19,0.25,0.24},
  {0.22,0.32,0.34,0.12},
  {0.27,0.07,0.13,0.13,0.13,0.13,0.14},
  {0.07,0.31,0.11,0.10,0.24,0.08,0.09},
  {0.07,0.31,0.11,0.10,0.24,0.08,0.09},
  {0.07,0.31,0.11,0.10,0.24,0.08,0.09},
  {0.07,0.31,0.11,0.10,0.24,0.08,0.09}
}
function Table(t)
  table_index = table_index + 1
  local w = widths[table_index]
  if w then
    assert(#t.colspecs == #w, 'Unexpected table column count')
    for i,v in ipairs(w) do t.colspecs[i] = {t.colspecs[i][1],v} end
  end
  return t
end
function Code(c)
  if FORMAT == 'latex' and c.text:find('/',1,true) and not c.text:find('[{}]') then
    return pandoc.RawInline('latex', '\\path{' .. c.text .. '}')
  end
end
